# LocalCanvas V15.4

Galaxy S26 Ultra(12GB RAM, Adreno 840)를 대상으로 **PC·외부 유료 추론 API 없이** 스마트폰 내부에서 `stable-diffusion.cpp` + Vulkan으로 이미지를 생성하는 오프라인 Android 프로젝트입니다.

- **엔진 호환성**: `ENGINE_API_COMPATIBILITY.md`
- **빌드·실기기 체크리스트**: `INSTALL_AND_DEVICE_CHECKLIST.md`
- **기능 현황·버그·테스트 보고서**: `FEATURE_STATUS.md`, `BUG_TRACKER.md`, `BUILD_REPORT.md`, `TEST_REPORT.md`, `REGRESSION_REPORT.md`
