cmake_minimum_required(VERSION 3.22.1)
project(localcanvas_native LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(LOCALCANVAS_HAS_SDCPP 0)
option(LOCALCANVAS_REQUIRE_SDCPP "Fail configuration when the real engine is absent" OFF)

add_library(localcanvas_native SHARED localcanvas_jni.cpp)

if(SDCPP_DIR AND EXISTS "${SDCPP_DIR}/CMakeLists.txt")
    set(SD_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
    set(SD_BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
    set(SD_VULKAN ON CACHE BOOL "" FORCE)
    set(SD_OPENCL OFF CACHE BOOL "" FORCE)
    add_subdirectory("${SDCPP_DIR}" "${CMAKE_BINARY_DIR}/stable-diffusion.cpp")
    target_include_directories(localcanvas_native PRIVATE "${SDCPP_DIR}/include")
    target_compile_definitions(localcanvas_native PRIVATE LOCALCANVAS_HAS_SDCPP=1)
    target_link_libraries(localcanvas_native PRIVATE stable-diffusion)
    set(LOCALCANVAS_HAS_SDCPP 1)
endif()

if(LOCALCANVAS_REQUIRE_SDCPP AND NOT LOCALCANVAS_HAS_SDCPP)
    message(FATAL_ERROR "LocalCanvas requires stable-diffusion.cpp; SDCPP_DIR was not supplied")
endif()

target_compile_definitions(localcanvas_native PRIVATE LOCALCANVAS_HAS_SDCPP=${LOCALCANVAS_HAS_SDCPP})

find_library(log-lib log)
find_library(android-lib android)
find_library(jnigraphics-lib jnigraphics)
find_library(vulkan-lib vulkan)
target_link_libraries(localcanvas_native PRIVATE ${log-lib} ${android-lib} ${jnigraphics-lib} ${vulkan-lib})
