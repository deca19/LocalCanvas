#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <cstdint>
#include <cstring>
#include <string>
#include <atomic>
#include <mutex>

#ifndef LOCALCANVAS_HAS_SDCPP
#define LOCALCANVAS_HAS_SDCPP 0
#endif

#if LOCALCANVAS_HAS_SDCPP
#include "stable-diffusion.h"
static std::atomic<int> g_progress{0};
static std::mutex g_engine_mutex;
static sd_ctx_t* g_running_ctx = nullptr;
static sd_ctx_t* g_cached_ctx = nullptr;
static std::string g_cached_model;
static void progressCallback(const sd_generation_progress_t* p, void*) {
    if (p && p->total > 0) g_progress.store((int)((p->completed * 100) / p->total));
}
#endif

#define LOG_TAG "LocalCanvasNative"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static void throwJava(JNIEnv* env, const char* type, const std::string& message) {
    jclass cls = env->FindClass(type);
    if (cls) env->ThrowNew(cls, message.c_str());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_localcanvas_app_NativeEngine_nativeIsAvailable(JNIEnv*, jclass) {
#if LOCALCANVAS_HAS_SDCPP
    return JNI_TRUE;
#else
    return JNI_FALSE;
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_localcanvas_app_NativeEngine_nativeBackendStatus(JNIEnv* env, jclass) {
#if LOCALCANVAS_HAS_SDCPP
    return env->NewStringUTF("stable-diffusion.cpp native engine linked; Vulkan build requested; runtime unverified");
#else
    return env->NewStringUTF("native library loaded, but stable-diffusion.cpp is not linked");
#endif
}

extern "C" JNIEXPORT jint JNICALL
Java_com_localcanvas_app_NativeEngine_nativeProgress(JNIEnv*, jclass) {
#if LOCALCANVAS_HAS_SDCPP
    return g_progress.load();
#else
    return -1;
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_localcanvas_app_NativeEngine_nativeCancel(JNIEnv*, jclass) {
#if LOCALCANVAS_HAS_SDCPP
    if (g_running_ctx) sd_cancel_generation(g_running_ctx, SD_CANCEL_ALL);
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_localcanvas_app_NativeEngine_nativeUnload(JNIEnv*, jclass) {
#if LOCALCANVAS_HAS_SDCPP
    std::lock_guard<std::mutex> lock(g_engine_mutex);
    if (g_cached_ctx) {
        sd_dgl_ctx_t* dgl = sd_ctx_get_dgl_ctx(g_cached_ctx);
        if (dgl) { sd_dgl_ctx_unload_models(dgl); sd_dgl_ctx_release_staging(dgl); }
        if (g_cached_ctx != g_running_ctx) sd_ctx_free(g_cached_ctx);
        g_cached_ctx = nullptr;
        g_cached_model.clear();
    }
    g_progress.store(0);
#endif
}

#if LOCALCANVAS_HAS_SDCPP
static jobject createBitmap(JNIEnv* env, const uint8_t* src, int width, int height, int channels) {
    jclass configClass = env->FindClass("android/graphics/Bitmap$Config");
    jfieldID argb = env->GetStaticFieldID(configClass, "ARGB_8888", "Landroid/graphics/Bitmap$Config;");
    jobject config = env->GetStaticObjectField(configClass, argb);
    jclass bitmapClass = env->FindClass("android/graphics/Bitmap");
    jmethodID create = env->GetStaticMethodID(bitmapClass, "createBitmap", "(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;");
    jobject bitmap = env->CallStaticObjectMethod(bitmapClass, create, width, height, config);
    if (!bitmap || env->ExceptionCheck()) return nullptr;
    AndroidBitmapInfo info{};
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return nullptr;
    void* pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS) return nullptr;
    for (int y = 0; y < height; ++y) {
        auto* row = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(pixels) + y * info.stride);
        for (int x = 0; x < width; ++x) {
            const size_t i = static_cast<size_t>(y * width + x) * channels;
            const uint8_t r = src[i];
            const uint8_t g = channels > 1 ? src[i + 1] : r;
            const uint8_t b = channels > 2 ? src[i + 2] : r;
            row[x] = 0xff000000u | (static_cast<uint32_t>(r) << 16) |
                     (static_cast<uint32_t>(g) << 8) | static_cast<uint32_t>(b);
        }
    }
    AndroidBitmap_unlockPixels(env, bitmap);
    return bitmap;
}
#endif

extern "C" JNIEXPORT jobject JNICALL
Java_com_localcanvas_app_NativeEngine_nativeGenerate(JNIEnv* env, jclass,
        jstring jModel, jstring jPrompt, jstring jNegative, jint width, jint height,
        jint steps, jfloat cfg, jlong seed, jint threads) {
#if !LOCALCANVAS_HAS_SDCPP
    throwJava(env, "java/lang/UnsupportedOperationException", "stable-diffusion.cpp is not linked into this build");
    return nullptr;
#else
    const char* model = env->GetStringUTFChars(jModel, nullptr);
    const char* prompt = env->GetStringUTFChars(jPrompt, nullptr);
    const char* negative = env->GetStringUTFChars(jNegative, nullptr);
    jobject output = nullptr;
    sd_ctx_opt_t* ctxOpt = sd_ctx_opt_create();
    sd_ctx_t* ctx = nullptr;
    sd_img_gen_opt_t* imageOpt = nullptr;
    sd_result_t* result = nullptr;
    {
        std::lock_guard<std::mutex> lock(g_engine_mutex);
        if (g_cached_ctx && g_cached_model == model) {
            ctx = g_cached_ctx;
        } else {
            if (g_cached_ctx) { sd_ctx_free(g_cached_ctx); g_cached_ctx = nullptr; g_cached_model.clear(); }
            if (!ctxOpt || sd_opt_set_string(ctxOpt, "model_path", model) != SD_STATUS_OK ||
                sd_opt_set_int(ctxOpt, "n_threads", threads > 0 ? threads : 4) != SD_STATUS_OK ||
                sd_ctx_create(ctxOpt, &ctx) != SD_STATUS_OK) {
                throwJava(env, "java/lang/IllegalStateException", sd_get_last_error());
                goto cleanup;
            }
            g_cached_ctx = ctx;
            g_cached_model = model;
        }
    }
    g_running_ctx = ctx;
    sd_set_generation_progress_callback(ctx, progressCallback, nullptr);
    g_progress.store(0);
    imageOpt = sd_img_gen_opt_create();
    if (!imageOpt || sd_opt_set_string(imageOpt, "prompt", prompt) != SD_STATUS_OK ||
        sd_opt_set_string(imageOpt, "negative_prompt", negative) != SD_STATUS_OK ||
        sd_opt_set_int(imageOpt, "width", width) != SD_STATUS_OK ||
        sd_opt_set_int(imageOpt, "height", height) != SD_STATUS_OK ||
        sd_opt_set_int(imageOpt, "seed", seed) != SD_STATUS_OK ||
        sd_opt_set_int(imageOpt, "sample.steps", steps) != SD_STATUS_OK ||
        sd_opt_set_float(imageOpt, "sample.guidance.txt_cfg", cfg) != SD_STATUS_OK ||
        sd_opt_set_string(imageOpt, "sample.method", "euler") != SD_STATUS_OK ||
        sd_generate_image(ctx, imageOpt, &result) != SD_STATUS_OK) {
        throwJava(env, "java/lang/IllegalStateException", sd_get_last_error());
        goto cleanup;
    }
    if (!result || sd_result_get_image_count(result) < 1) {
        throwJava(env, "java/lang/IllegalStateException", "engine returned no image");
        goto cleanup;
    }
    {
        const sd_tensor_t* image = sd_result_get_image(result, 0);
        const void* data = sd_tensor_data(image);
        const size_t bytes = sd_tensor_byte_size(image);
        const int channels = bytes >= static_cast<size_t>(width * height * 4) ? 4 : 3;
        if (!image || !data || bytes < static_cast<size_t>(width * height * channels)) {
            throwJava(env, "java/lang/IllegalStateException", "invalid image tensor returned by engine");
            goto cleanup;
        }
        output = createBitmap(env, static_cast<const uint8_t*>(data), width, height, channels);
    }
cleanup:
    g_running_ctx = nullptr;
    if (result) sd_result_free(result);
    if (imageOpt) sd_opt_free(imageOpt);
    // The context is intentionally retained for the next generation. nativeUnload()
    // releases its model components and destroys it when the model is switched/off.
    if (ctxOpt) sd_opt_free(ctxOpt);
    env->ReleaseStringUTFChars(jModel, model);
    env->ReleaseStringUTFChars(jPrompt, prompt);
    env->ReleaseStringUTFChars(jNegative, negative);
    return output;
#endif
}
