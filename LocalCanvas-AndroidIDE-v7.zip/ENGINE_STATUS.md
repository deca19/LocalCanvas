# LocalCanvas 엔진 상태

## 이번 단계에서 실제로 추가한 것

- Android NDK/CMake 외부 네이티브 빌드 경로
- `arm64-v8a` ABI 제한
- `localcanvas_native.so` JNI 브리지
- stable-diffusion.cpp의 공식 C API를 호출하는 Text-to-Image 경로
- 생성된 U8 이미지 텐서를 Android `Bitmap`으로 변환하는 코드
- 엔진 미연결 빌드에서 생성 기능을 거짓으로 표시하지 않는 fallback
- CI에서 upstream 엔진을 shallow clone으로 가져오는 빌드 단계
- APK 내부 ARM64 `.so` 파일과 ELF machine 정보를 검사하는 단계
- 생성 화면에서 실제 `nativeGenerate` 호출 및 백그라운드 실행
- 모델 파일 가져오기/URL 다운로드/SHA-256 검사/삭제
- 생성 Bitmap의 실제 갤러리 저장
- 네이티브 진행 콜백, 취소 요청, 모델 메모리 해제 요청

## 아직 미완료 또는 실기기 검증 필요

- 모델 검색/공식 저장소 카탈로그와 모델별 라이선스 표시
- 다운로드 일시정지/재개 및 작업 영속화
- LoRA/VAE/ControlNet 선택 UI와 모델별 호환성 검사
- 생성 대기열, 백그라운드 작업의 영속화, 갤러리 메타데이터 복원
- Vulkan이 Galaxy S26 Ultra의 실제 Adreno 드라이버에서 정상 실행되는지 여부
- SD 1.5, SDXL, Illustrious XL, NoobAI XL, FLUX 등 각 모델의 실제 기기별 RAM/속도 측정

빌드 성공만으로 위 미완료 기능을 구현했다고 표시하지 않는다. 모델을 포함하지 않은 APK는 앱 설치 후 모델 파일을 별도로 받아야 생성할 수 있다.
