package com.localcanvas.app;

import android.graphics.Bitmap;

/** JNI boundary for the real native engine. It never fabricates an image. */
public final class NativeEngine {
    private static final boolean LOADED;
    static {
        boolean loaded;
        try { System.loadLibrary("localcanvas_native"); loaded = true; }
        catch (UnsatisfiedLinkError error) { loaded = false; }
        LOADED = loaded;
    }
    private NativeEngine() {}
    public static boolean isNativeLibraryLoaded() { return LOADED; }
    public static native boolean nativeIsAvailable();
    public static native String nativeRuntimeStatus();
    public static native String nativeBackendStatus();
    public static native String nativeLastError();
    public static native boolean nativeIsGenerating();
    public static native Bitmap nativeGenerate(String modelPath, String prompt, String negativePrompt,
            int width, int height, int steps, float cfg, long seed, int threads,
            String sampler, String scheduler);
    public static native void nativeCancel();
    public static native boolean nativeUnload();
    public static native int nativeProgress();
}
