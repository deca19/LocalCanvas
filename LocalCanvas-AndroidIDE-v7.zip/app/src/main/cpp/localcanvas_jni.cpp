#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <atomic>
#include <cstdint>
#include <mutex>
#include <string>

#ifndef LOCALCANVAS_HAS_SDCPP
#define LOCALCANVAS_HAS_SDCPP 0
#endif
#define LOG_TAG "LocalCanvasNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::mutex g_state_mutex;
static std::atomic<bool> g_generating{false};
static std::atomic<int> g_progress{0};
static std::string g_last_error;

#if LOCALCANVAS_HAS_SDCPP
#include "stable-diffusion.h"
static sd_ctx_t* g_cached_ctx = nullptr;
static std::string g_cached_model;
static std::string g_runtime_devices;
static std::once_flag g_runtime_init;
static void setError(const char* text){std::lock_guard<std::mutex> l(g_state_mutex);g_last_error=text?text:"unknown native error";}
static void logCallback(enum sd_log_level_t level,const char* text,void*){if(!text)return;if(level>=SD_LOG_ERROR)LOGE("sd.cpp: %s",text);else LOGI("sd.cpp: %s",text);}
static void progressCallback(const sd_generation_progress_t* p,void*){if(p&&p->total>0)g_progress.store((int)((p->completed*100)/p->total));}
static void initRuntime(){sd_set_log_callback(logCallback,nullptr);size_t n=sd_list_devices(nullptr,0);if(n){g_runtime_devices.resize(n);sd_list_devices(g_runtime_devices.data(),n+1);}}
static std::string engineError(const char* fallback){const char* e=sd_get_last_error();return(e&&*e)?std::string(e):std::string(fallback);}
#else
static void setError(const char* text){std::lock_guard<std::mutex> l(g_state_mutex);g_last_error=text?text:"unknown native error";}
#endif

static void throwJava(JNIEnv* env,const char* type,const std::string& message){jclass cls=env->FindClass(type);if(cls)env->ThrowNew(cls,message.c_str());}

extern "C" JNIEXPORT jboolean JNICALL Java_com_localcanvas_app_NativeEngine_nativeIsAvailable(JNIEnv*,jclass){
#if LOCALCANVAS_HAS_SDCPP
 std::call_once(g_runtime_init,initRuntime);return JNI_TRUE;
#else
 return JNI_FALSE;
#endif
}
extern "C" JNIEXPORT jstring JNICALL Java_com_localcanvas_app_NativeEngine_nativeRuntimeStatus(JNIEnv* env,jclass){
#if LOCALCANVAS_HAS_SDCPP
 std::call_once(g_runtime_init,initRuntime);std::string s="engine=stable-diffusion.cpp; commit=52491bd; vulkan=compiled; devices="+g_runtime_devices;return env->NewStringUTF(s.c_str());
#else
 return env->NewStringUTF("engine=unavailable");
#endif
}
extern "C" JNIEXPORT jstring JNICALL Java_com_localcanvas_app_NativeEngine_nativeBackendStatus(JNIEnv* env,jclass){
#if LOCALCANVAS_HAS_SDCPP
 std::call_once(g_runtime_init,initRuntime);std::string s="stable-diffusion.cpp linked; Vulkan compiled; devices: "+g_runtime_devices;return env->NewStringUTF(s.c_str());
#else
 return env->NewStringUTF("native library loaded, stable-diffusion.cpp unavailable");
#endif
}
extern "C" JNIEXPORT jstring JNICALL Java_com_localcanvas_app_NativeEngine_nativeLastError(JNIEnv* env,jclass){std::lock_guard<std::mutex> l(g_state_mutex);return env->NewStringUTF(g_last_error.c_str());}
extern "C" JNIEXPORT jboolean JNICALL Java_com_localcanvas_app_NativeEngine_nativeIsGenerating(JNIEnv*,jclass){return g_generating.load()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT jint JNICALL Java_com_localcanvas_app_NativeEngine_nativeProgress(JNIEnv*,jclass){return g_progress.load();}
extern "C" JNIEXPORT void JNICALL Java_com_localcanvas_app_NativeEngine_nativeCancel(JNIEnv*,jclass){
#if LOCALCANVAS_HAS_SDCPP
 std::lock_guard<std::mutex> l(g_state_mutex);if(g_cached_ctx&&g_generating.load())sd_cancel_generation(g_cached_ctx,SD_CANCEL_ALL);
#endif
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_localcanvas_app_NativeEngine_nativeUnload(JNIEnv*,jclass){
#if LOCALCANVAS_HAS_SDCPP
 if(g_generating.load()){setError("cannot unload a model while generation is running");return JNI_FALSE;}std::lock_guard<std::mutex> l(g_state_mutex);if(g_cached_ctx){sd_dgl_ctx_t* d=sd_ctx_get_dgl_ctx(g_cached_ctx);if(d){sd_dgl_ctx_unload_models(d);sd_dgl_ctx_release_staging(d);}sd_ctx_free(g_cached_ctx);g_cached_ctx=nullptr;g_cached_model.clear();}g_progress.store(0);return JNI_TRUE;
#else
 return JNI_FALSE;
#endif
}

#if LOCALCANVAS_HAS_SDCPP
static jobject createBitmap(JNIEnv* env,const sd_tensor_t* image,int rw,int rh){
 if(!image||sd_tensor_type(image)!=SD_TENSOR_U8||sd_tensor_rank(image)!=3){setError("engine returned a non-U8 rank-3 image tensor");return nullptr;}
 int c=(int)sd_tensor_dim(image,0),w=(int)sd_tensor_dim(image,1),h=(int)sd_tensor_dim(image,2);if(c!=3||w<=0||h<=0||w!=rw||h!=rh){setError("image tensor shape is not RGB [3,width,height] matching the request");return nullptr;}
 size_t expected=(size_t)c*w*h;if(sd_tensor_byte_size(image)!=expected||!sd_tensor_data(image)){setError("image tensor byte size or data pointer is invalid");return nullptr;}
 jclass cc=env->FindClass("android/graphics/Bitmap$Config");jfieldID fid=env->GetStaticFieldID(cc,"ARGB_8888","Landroid/graphics/Bitmap$Config;");jobject config=env->GetStaticObjectField(cc,fid);jclass bc=env->FindClass("android/graphics/Bitmap");jmethodID create=env->GetStaticMethodID(bc,"createBitmap","(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;");jobject bitmap=env->CallStaticObjectMethod(bc,create,w,h,config);if(!bitmap||env->ExceptionCheck())return nullptr;
 AndroidBitmapInfo info{};if(AndroidBitmap_getInfo(env,bitmap,&info)!=ANDROID_BITMAP_RESULT_SUCCESS||info.format!=ANDROID_BITMAP_FORMAT_RGBA_8888){setError("Android Bitmap is not RGBA_8888");return nullptr;}void* pixels=nullptr;if(AndroidBitmap_lockPixels(env,bitmap,&pixels)!=ANDROID_BITMAP_RESULT_SUCCESS)return nullptr;const auto* src=(const uint8_t*)sd_tensor_data(image);
 for(int y=0;y<h;y++){auto* row=(uint32_t*)((uint8_t*)pixels+y*info.stride);for(int x=0;x<w;x++){size_t i=((size_t)y*w+x)*3;row[x]=0xff000000u|((uint32_t)src[i]<<16)|((uint32_t)src[i+1]<<8)|src[i+2];}}AndroidBitmap_unlockPixels(env,bitmap);return bitmap;
}
#endif

extern "C" JNIEXPORT jobject JNICALL Java_com_localcanvas_app_NativeEngine_nativeGenerate(JNIEnv* env,jclass,jstring jm,jstring jp,jstring jn,jint width,jint height,jint steps,jfloat cfg,jlong seed,jint threads,jstring jsampler,jstring jscheduler){
#if !LOCALCANVAS_HAS_SDCPP
 throwJava(env,"java/lang/UnsupportedOperationException","stable-diffusion.cpp is not linked into this build");return nullptr;
#else
 if(width<64||height<64||width>2048||height>2048||steps<1||steps>200){throwJava(env,"java/lang/IllegalArgumentException","invalid generation dimensions or steps");return nullptr;}bool idle=false;if(!g_generating.compare_exchange_strong(idle,true)){throwJava(env,"java/lang/IllegalStateException","another generation is already running");return nullptr;}
 const char* model=env->GetStringUTFChars(jm,nullptr),*prompt=env->GetStringUTFChars(jp,nullptr),*negative=env->GetStringUTFChars(jn,nullptr);const char* sampler=jsampler?env->GetStringUTFChars(jsampler,nullptr):nullptr;const char* scheduler=jscheduler?env->GetStringUTFChars(jscheduler,nullptr):nullptr;sd_ctx_t* ctx=nullptr;sd_ctx_opt_t* co=sd_ctx_opt_create();sd_img_gen_opt_t* io=nullptr;sd_result_t* result=nullptr;jobject output=nullptr;std::string failure;
 {std::lock_guard<std::mutex> l(g_state_mutex);if(g_cached_ctx&&g_cached_model==model)ctx=g_cached_ctx;else{if(g_cached_ctx){sd_ctx_free(g_cached_ctx);g_cached_ctx=nullptr;g_cached_model.clear();}if(!co||sd_opt_set_string(co,"model_path",model)!=SD_STATUS_OK||sd_opt_set_int(co,"n_threads",threads>0?threads:4)!=SD_STATUS_OK||sd_opt_set_string(co,"params_backend","vulkan")!=SD_STATUS_OK||sd_ctx_create(co,&ctx)!=SD_STATUS_OK)failure=engineError("context creation failed");else{g_cached_ctx=ctx;g_cached_model=model;}}}
 if(failure.empty()&&!sd_ctx_supports_image_generation(ctx)){const char* v=sd_get_model_version_name(ctx);failure=std::string("model does not support image generation: ")+(v?v:"unknown");}
 if(failure.empty()){sd_set_generation_progress_callback(ctx,progressCallback,nullptr);g_progress.store(0);io=sd_img_gen_opt_create();if(!io||sd_opt_set_string(io,"prompt",prompt)!=SD_STATUS_OK||sd_opt_set_string(io,"negative_prompt",negative)!=SD_STATUS_OK||sd_opt_set_int(io,"width",width)!=SD_STATUS_OK||sd_opt_set_int(io,"height",height)!=SD_STATUS_OK||sd_opt_set_int(io,"seed",seed)!=SD_STATUS_OK||sd_opt_set_int(io,"sample.steps",steps)!=SD_STATUS_OK||sd_opt_set_float(io,"sample.guidance.txt_cfg",cfg)!=SD_STATUS_OK||(sampler&&*sampler&&sd_opt_set_string(io,"sample.method",sampler)!=SD_STATUS_OK)||(scheduler&&*scheduler&&sd_opt_set_string(io,"sample.scheduler",scheduler)!=SD_STATUS_OK)||sd_generate_image(ctx,io,&result)!=SD_STATUS_OK)failure=engineError("image generation failed");}
 if(failure.empty()&&(!result||sd_result_get_image_count(result)<1))failure="engine returned no image";if(failure.empty())output=createBitmap(env,sd_result_get_image(result,0),width,height);if(!output&&failure.empty())failure="failed to convert image tensor to Bitmap";
 if(result)sd_result_free(result);if(io)sd_opt_free(io);if(co)sd_opt_free(co);env->ReleaseStringUTFChars(jm,model);env->ReleaseStringUTFChars(jp,prompt);env->ReleaseStringUTFChars(jn,negative);if(sampler)env->ReleaseStringUTFChars(jsampler,sampler);if(scheduler)env->ReleaseStringUTFChars(jscheduler,scheduler);g_generating.store(false);
 if(!failure.empty()){setError(failure.c_str());throwJava(env,"java/lang/IllegalStateException",failure);return nullptr;}g_last_error.clear();return output;
#endif
}
