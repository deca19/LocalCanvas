# LocalCanvas V7 검증 상태

## 이번 버전에서 실제 수정한 항목

- `CancellationException` 명시적 import 추가
- 모델 선택과 ON/OFF 버튼 분리
- SD 1.5·SDXL 카탈로그 URL/용량 등록, SDXL SHA-256 등록
- 다운로드 전 저장 공간 확인
- HTTP Range 재개 시 Content-Range 검증
- 카탈로그 모델 파일 크기 검증
- 모델 ID와 실제 설치 파일의 일치 확인
- 생성 성공은 실제 Bitmap 반환 및 저장 시도 결과가 있을 때만 완료 표시
- 표준 Gradle Wrapper 8.9 적용
- Gradle 8.9 배포 SHA-256 고정
- GitHub Actions에 Wrapper 검증 및 Gradle 설정 단계 추가
- V7용 stable-diffusion.cpp 커밋 고정 빌드 workflow 유지

## 로컬 자동 검증

- Wrapper JAR SHA-256: `498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17`
- Gradle 8.9 binary ZIP SHA-256: `d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab`
- 로컬 Gradle 실행: Android Gradle Plugin을 네트워크에서 받을 수 없어 중단됨
- 실패 지점: `com.android.application:com.android.application.gradle.plugin:8.7.3` 해석 단계
- 따라서 이 환경에서는 APK 생성 성공을 주장하지 않음

## 아직 실기기 또는 Actions에서 확인해야 하는 항목

- GitHub Actions에서 Android SDK·NDK·stable-diffusion.cpp를 실제로 내려받은 뒤 컴파일
- APK 내부 `arm64-v8a/liblocalcanvas_native.so`의 실제 ELF 및 링크 검증
- S26 Ultra에서 Vulkan 장치가 실제 선택되는지 확인
- 실제 SD 1.5 모델을 내려받아 이미지 생성 및 PNG 저장 확인
- SDXL 파생 모델, LoRA, VAE, ControlNet, FLUX, SD3.5는 모델별 별도 검증 필요
- 기기 RAM·발열·배터리 측정은 실기기에서만 가능

## 자동 설치 불가로 표시하는 모델

라이선스와 공개 파일의 정확한 크기·SHA-256을 확인하지 못한 Illustrious XL, NoobAI XL, Pony XL, Animagine XL, FLUX, SD3.5는 자동 다운로드 URL을 등록하지 않았다. 사용자가 공식 출처와 라이선스를 확인한 뒤 사용자 모델 가져오기 또는 직접 URL 입력으로 설치해야 한다.
