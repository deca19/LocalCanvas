# LocalCanvas

S26 Ultra를 목표로 하는 모바일 로컬 AI 이미지 생성 플랫폼입니다. 현재는 Android ARM64 네이티브 엔진 연결을 우선 진행하는 개발 빌드입니다.

## 현재 구현

- 실제 Android 앱 화면 골격
- 홈/생성/모델/갤러리/설정 하단 메뉴
- 모델 상태를 `미설치`로 표시하는 관리 화면
- 실제 엔진이 연결되기 전 허위 이미지·진행률·성능값을 표시하지 않음
- NDK/CMake와 `arm64-v8a` JNI 브리지
- stable-diffusion.cpp 공식 C API 기반 Text-to-Image 호출 경로

## 아직 미구현

Android SDK와 실제 기기 없이 다음 항목은 검증할 수 없습니다.

- Galaxy S26 Ultra Adreno 실기기 추론 검증
- SD 1.5/SDXL/FLUX 각 모델의 실기기 생성 검증
- 모델 다운로드·삭제·무결성 검사
- LoRA/VAE/ControlNet
- S26 Ultra의 RAM·발열·속도 측정

## 현재 제한 및 다음 개발 순서

1. CI에서 upstream 엔진이 포함된 ARM64 APK 빌드 및 ELF 검사
2. 모델 저장소·해시 검증·중단/재개 다운로드 구현
3. S26 Ultra에서 SD 1.5 단일 모델 생성 성공 확인
4. Vulkan/FP16/메모리/발열 측정
5. SDXL 및 선택적 모델 설치 확장

## 엔진 선정 메모

초기 후보는 `stable-diffusion.cpp`의 C/C++ 네이티브 엔진과 Vulkan 백엔드입니다. 이 프로젝트는 safetensors/GGUF 계열과 Vulkan 지원을 제공하지만, Android Adreno에서의 안정성은 실제 기기별 검증이 필요합니다. Android NDK에서는 Vulkan을 런타임에 확인해야 하며, 지원되지 않는 기기에서는 실행하지 않습니다.

앱 코드에는 `EngineContract`와 `NativeEngine` JNI 경계를 두어 UI와 추론 엔진을 분리했습니다. 모델 경로가 없는 상태에서는 생성 결과를 꾸며내지 않습니다.

1. SD 1.5 단일 safetensors/GGUF 모델 로딩
2. CPU 기준 생성 성공 확인
3. Vulkan 사용 가능 여부 확인
4. FP16 및 메모리 절약 옵션 검증
5. 실패 시 CPU 폴백 또는 명확한 오류 표시

현재 웹 검색 자료만으로 S26 Ultra의 실제 생성 속도나 안정성을 확정하지 않았습니다.

구현/미구현 세부 목록은 `ENGINE_STATUS.md`에 기록합니다. 이 프로젝트는 아직 최종 완성본이 아니며, 특히 모델 관리자와 S26 Ultra 실기기 검증이 남아 있습니다.
