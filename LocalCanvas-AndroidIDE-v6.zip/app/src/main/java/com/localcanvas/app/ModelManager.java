package com.localcanvas.app;

import android.content.Context;
import android.net.Uri;
import android.os.StatFs;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Owns model files in app-private storage. It never executes downloaded files. */
public final class ModelManager {
 public interface Progress { void onProgress(long done,long total,long elapsedMs); }
 public static final class Model {
 public final String id,name,architecture,license; public final long expectedBytes; public final File file; public final String downloadUrl,sha256;
  Model(String i,String n,String a,String l,long bytes,String url,String hash,File f){id=i;name=n;architecture=a;license=l;expectedBytes=bytes;downloadUrl=url;sha256=hash;file=f;}
  public boolean isInstalled(){return file.isFile()&&file.length()>0;}
 }
 private static final class Spec {String id,name,arch,license;long bytes;String url,sha256;Spec(String i,String n,String a,String l,long b,String u,String h){id=i;name=n;arch=a;license=l;bytes=b;url=u;sha256=h;}}
 private final Context context; private final File root;
 private static final List<Spec> CATALOG=Arrays.asList(
  new Spec("sd15","Stable Diffusion 1.5","SD 1.x","CreativeML Open RAIL-M",4270000000L,"https://huggingface.co/stable-diffusion-v1-5/stable-diffusion-v1-5/resolve/main/v1-5-pruned-emaonly.safetensors",null),
  new Spec("sd2","Stable Diffusion 2.x","SD 2.x","Stability AI license; verify source",0,null,null),
  new Spec("sdxl","Stable Diffusion XL","SDXL","Stability AI license",6940000000L,"https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors","31e35c80fc4829d14f90153f4c74cd59c90b779f6afe05a74cd6120b893f7e5b"),
  new Spec("illustrious-xl","Illustrious XL","SDXL derivative","저작자 라이선스 확인 필요",0,null,null),
  new Spec("noobai-xl","NoobAI XL","SDXL derivative","저작자 라이선스 확인 필요",0,null,null),
  new Spec("pony-xl","Pony Diffusion XL","SDXL derivative","저작자 라이선스 확인 필요",0,null,null),
  new Spec("animagine-xl","Animagine XL","SDXL derivative","저작자 라이선스 확인 필요",0,null,null),
  new Spec("flux","FLUX","DiT/FLUX","접근 조건·라이선스 확인 필요",0,null,null),
  new Spec("sd35","Stable Diffusion 3.5","MMDiT","접근 조건·라이선스 확인 필요",0,null,null));
 public ModelManager(Context c){context=c.getApplicationContext();root=new File(context.getFilesDir(),"models");if(!root.exists())root.mkdirs();}
 public File directory(){return root;}
 public List<Model> list(){List<Model> out=new ArrayList<>();for(Spec s:CATALOG)out.add(new Model(s.id,s.name,s.arch,s.license,s.bytes,s.url,s.sha256,fileFor(s.id)));File[] files=root.listFiles((d,n)->n.endsWith(".model"));if(files!=null)for(File f:files){String id=f.getName().substring(0,f.getName().length()-6);boolean known=false;for(Spec s:CATALOG)if(s.id.equals(id))known=true;if(!known)out.add(new Model(id,"사용자 모델: "+id,"사용자 지정","사용자 확인",f.length(),null,null,f));}return out;}
 public Model find(String id){for(Model m:list())if(m.id.equals(id))return m;return null;}
 private File fileFor(String id){return new File(root,id+".model");}
 private static String validId(String id){if(id==null||!id.matches("[A-Za-z0-9][A-Za-z0-9._-]{0,63}"))throw new IllegalArgumentException("모델 ID 형식이 올바르지 않습니다");return id;}
 public long freeBytes(){return new StatFs(root.getAbsolutePath()).getAvailableBytes();}
 public File importFile(Uri uri,String id)throws IOException{validId(id);File dest=fileFor(id);File part=new File(dest.getPath()+".part");try(InputStream in=context.getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("파일을 열 수 없습니다");try(OutputStream out=new BufferedOutputStream(new FileOutputStream(part))){byte[] buf=new byte[1024*1024];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}}if(part.length()==0){part.delete();throw new IOException("빈 모델 파일입니다");}if(dest.exists()&&!dest.delete()){part.delete();throw new IOException("기존 모델 파일을 교체할 수 없습니다");}if(!part.renameTo(dest)){part.delete();throw new IOException("모델 파일 확정에 실패했습니다");}return dest;}
 public File download(String id,String url,String expected,Progress progress,AtomicBoolean cancel)throws Exception{
  validId(id);if(url==null||!url.toLowerCase(Locale.US).startsWith("https://"))throw new IllegalArgumentException("HTTPS 다운로드 URL만 허용합니다");File dest=fileFor(id),part=new File(dest.getPath()+".part");long offset=part.isFile()?part.length():0;HttpURLConnection h=null;long start=System.currentTimeMillis();try{
   h=(HttpURLConnection)new URL(url).openConnection();h.setConnectTimeout(20000);h.setReadTimeout(60000);h.setInstanceFollowRedirects(true);if(offset>0)h.setRequestProperty("Range","bytes="+offset+"-");h.connect();int code=h.getResponseCode();if(code!=206&&code!=200)throw new IOException("HTTP "+code);if(code==200&&offset>0){part.delete();offset=0;h.disconnect();return download(id,url,expected,progress,cancel);}long total=h.getContentLengthLong();if(total>0)total+=offset;try(InputStream in=new BufferedInputStream(h.getInputStream());OutputStream out=new BufferedOutputStream(new FileOutputStream(part,offset>0))){byte[] buf=new byte[1024*1024];long done=offset;int n;while((n=in.read(buf))!=-1){if(cancel!=null&&cancel.get()){throw new CancellationException("다운로드가 취소되었습니다");}out.write(buf,0,n);done+=n;if(progress!=null)progress.onProgress(done,total,System.currentTimeMillis()-start);}}
   if(part.length()==0)throw new IOException("빈 모델 파일입니다");if(expected!=null&&!expected.trim().isEmpty()&&!expected.equalsIgnoreCase(hash(part)))throw new IOException("SHA-256 무결성 검사 실패");if(dest.exists()&&!dest.delete())throw new IOException("기존 모델 파일을 교체할 수 없습니다");if(!part.renameTo(dest))throw new IOException("모델 파일 확정 실패");return dest;
  }catch(CancellationException e){throw e;}catch(Exception e){if(part.exists()&&expected!=null&&!expected.isEmpty())part.delete();throw e;}finally{if(h!=null)h.disconnect();}
 }
 public File download(String id,String url,String expected)throws Exception{return download(id,url,expected,null,new AtomicBoolean(false));}
 public boolean remove(String id){validId(id);if(NativeEngine.nativeIsGenerating())return false;File f=fileFor(id),p=new File(f.getPath()+".part");boolean ok=true;if(f.exists()&&!f.delete())ok=false;if(p.exists()&&!p.delete())ok=false;if(ok&&!NativeEngine.nativeUnload())ok=false;return ok;}
 public static String hash(File f)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte b:md.digest())s.append(String.format(Locale.US,"%02x",b));return s.toString();}
}
