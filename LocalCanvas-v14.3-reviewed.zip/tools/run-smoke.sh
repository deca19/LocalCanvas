#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
d=$(mktemp -d)
trap 'rm -rf "$d"' EXIT
p=app/src/main/java/com/localcanvas/app
java com.sun.tools.javac.Main -d "$d" "$p/DownloadValidator.java" "$p/AtomicModelFile.java" tools/Smoke.java
java -cp "$d" com.localcanvas.app.Smoke
