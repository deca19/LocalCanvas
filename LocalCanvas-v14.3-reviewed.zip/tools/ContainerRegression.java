package com.localcanvas.app;
import java.nio.file.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
public class ContainerRegression {
 public static void main(String[] args)throws Exception {
  Path p=Files.createTempFile("safetensors-test", ".bin");
  try {
   byte[] h="{\"x\":{\"dtype\":\"F32\",\"shape\":[1],\"data_offsets\":[0,4]}}".getBytes(StandardCharsets.UTF_8);
   byte[] b=ByteBuffer.allocate(8+h.length+4).order(ByteOrder.LITTLE_ENDIAN).putLong(h.length).put(h).putInt(0).array();
   Files.write(p,b);
   if(!DownloadValidator.isSupportedModel(p.toFile()))throw new AssertionError("valid SafeTensors rejected");
   Files.write(p,"GGUF1234".getBytes(StandardCharsets.US_ASCII));
   if(DownloadValidator.isSupportedModel(p.toFile()))throw new AssertionError("fake GGUF accepted");
   System.out.println("PASS: valid SafeTensors accepted; fake GGUF rejected");
  } finally {Files.deleteIfExists(p);}
 }
}
