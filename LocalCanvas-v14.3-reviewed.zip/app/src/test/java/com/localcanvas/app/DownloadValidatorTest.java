package com.localcanvas.app;

import org.junit.Test;
import java.io.*;
import java.nio.charset.StandardCharsets;
import static org.junit.Assert.*;

public class DownloadValidatorTest {
    @Test public void parsesValidRange()throws Exception{DownloadValidator.Range r=DownloadValidator.parseContentRange("bytes 10-19/100");assertEquals(10,r.start);assertEquals(19,r.end);assertEquals(100,r.total);}
    @Test(expected=IOException.class) public void rejectsBadRange()throws IOException{DownloadValidator.parseContentRange("bytes 20-10/100");}
    @Test public void acceptsMatchingResume()throws Exception{assertTrue(DownloadValidator.acceptsResume("bytes 10-99/100",10,10));}
    @Test public void rejectsMismatchedResume()throws Exception{assertFalse(DownloadValidator.acceptsResume("bytes 11-99/100",10,10));}
    @Test public void rejectsTruncatedGgufHeader()throws Exception{File f=File.createTempFile("model",".gguf");try(FileOutputStream o=new FileOutputStream(f)){o.write("GGUF".getBytes(StandardCharsets.US_ASCII));writeLe32(o,3);writeLe64(o,1);writeLe64(o,1);o.write(0);}assertFalse(DownloadValidator.isSupportedModel(f));assertTrue(f.delete());}
    @Test public void rejectsCorruptModel()throws Exception{File f=File.createTempFile("model",".bin");try(FileOutputStream o=new FileOutputStream(f)){o.write("bad-file".getBytes(StandardCharsets.US_ASCII));}assertFalse(DownloadValidator.isSupportedModel(f));assertTrue(f.delete());}
    @Test public void rejectsEightByteFakeGguf()throws Exception{File f=File.createTempFile("model",".bin");try(FileOutputStream o=new FileOutputStream(f)){o.write("GGUF1234".getBytes(StandardCharsets.US_ASCII));}assertFalse(DownloadValidator.isSupportedModel(f));assertTrue(f.delete());}
    @Test public void acceptsSafeTensorsWithBoundedOffsets()throws Exception{File f=File.createTempFile("model",".safetensors");String json="{\"x\":{\"dtype\":\"F32\",\"shape\":[1],\"data_offsets\":[0,4]}}";byte[] h=json.getBytes(StandardCharsets.UTF_8);try(FileOutputStream o=new FileOutputStream(f)){writeLe64(o,h.length);o.write(h);o.write(new byte[]{0,0,0,0});}assertTrue(DownloadValidator.isSupportedModel(f));assertTrue(f.delete());}
    @Test public void rejectsSafeTensorsOutOfBounds()throws Exception{File f=File.createTempFile("model",".safetensors");String json="{\"x\":{\"dtype\":\"F32\",\"shape\":[1],\"data_offsets\":[0,400]}}";byte[] h=json.getBytes(StandardCharsets.UTF_8);try(FileOutputStream o=new FileOutputStream(f)){writeLe64(o,h.length);o.write(h);o.write(new byte[]{0,0,0,0});}assertFalse(DownloadValidator.isSupportedModel(f));assertTrue(f.delete());}
    private static void writeLe32(OutputStream o,int v)throws IOException{for(int i=0;i<4;i++)o.write((v>>(8*i))&255);}
    private static void writeLe64(OutputStream o,long v)throws IOException{for(int i=0;i<8;i++)o.write((int)(v>>(8*i))&255);}
}
