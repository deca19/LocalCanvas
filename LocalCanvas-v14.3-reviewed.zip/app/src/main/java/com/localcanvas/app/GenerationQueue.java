package com.localcanvas.app;

import android.graphics.Bitmap;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Single-consumer inference queue. Activity lifetime is not the inference contract. */
public final class GenerationQueue {
    private static final GenerationQueue SHARED = new GenerationQueue(true);
    public interface Listener { void started(int index,int total); void completed(Bitmap image,int index); void failed(String message,int index); }
    public enum State { QUEUED, RUNNING, SUCCEEDED, FAILED, CANCELLED }
    public static final class Job {
        public final String id = UUID.randomUUID().toString();
        public final File model; public final String prompt,negative,sampler,scheduler;
        public final int width,height,steps,threads; public final float cfg; public final long seed;
        public Job(File m,String p,String n,int w,int h,int s,float c,long sd,int th,String sm,String sc){model=m;prompt=p;negative=n;width=w;height=h;steps=s;cfg=c;seed=sd;threads=th;sampler=sm;scheduler=sc;}
    }
    private static final class Work { final Job job; final Listener listener; final AtomicBoolean cancelled=new AtomicBoolean(); Work(Job j,Listener l){job=j;listener=l;} }
    private final BlockingQueue<Work> queue=new LinkedBlockingQueue<>();
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ConcurrentMap<String,State> states=new ConcurrentHashMap<>();
    private final ConcurrentMap<String,Boolean> activeModels=new ConcurrentHashMap<>();
    private final ConcurrentMap<String,Integer> modelRefs=new ConcurrentHashMap<>();
    private final AtomicBoolean stopped=new AtomicBoolean();
    public GenerationQueue(){this(false);}
    private GenerationQueue(boolean shared){worker.submit(this::consume);}
    public static GenerationQueue shared(){return SHARED;}
    public void submit(Job job,Listener listener){if(job==null||listener==null)throw new IllegalArgumentException("작업과 리스너가 필요합니다");if(stopped.get())throw new RejectedExecutionException("생성 큐가 종료되었습니다");states.put(job.id,State.QUEUED);if(job.model!=null)modelRefs.merge(job.model.getAbsolutePath(),1,Integer::sum);queue.offer(new Work(job,listener));}
    private void consume(){while(!stopped.get()){try{Work w=queue.take();if(stopped.get()){releaseModel(w.job.model);return;}int total=queue.size()+1,index=0;if(w.cancelled.get()){states.put(w.job.id,State.CANCELLED);releaseModel(w.job.model);continue;}states.put(w.job.id,State.RUNNING);if(w.job.model!=null)activeModels.put(w.job.model.getAbsolutePath(),Boolean.TRUE);safeStarted(w.listener,index,total);try{if(w.job.model==null||!w.job.model.isFile())throw new IOException("모델 파일이 없습니다");Bitmap image=NativeEngine.nativeGenerate(w.job.model.getAbsolutePath(),w.job.prompt,w.job.negative,w.job.width,w.job.height,w.job.steps,w.job.cfg,w.job.seed,w.job.threads,w.job.sampler,w.job.scheduler);if(image==null){states.put(w.job.id,State.FAILED);safeFailed(w.listener,"엔진이 이미지를 반환하지 않았습니다",index);}else{states.put(w.job.id,State.SUCCEEDED);safeCompleted(w.listener,image,index);}}catch(Throwable e){states.put(w.job.id,State.FAILED);String msg="네이티브 생성 오류";try{String z=NativeEngine.nativeLastError();if(z!=null&&!z.isEmpty())msg=z;}catch(Throwable ignored){}safeFailed(w.listener,msg,index);}finally{if(w.job.model!=null)activeModels.remove(w.job.model.getAbsolutePath());releaseModel(w.job.model);}}catch(InterruptedException e){if(stopped.get())return;Thread.currentThread().interrupt();}}}
    private static void safeStarted(Listener l,int i,int t){try{l.started(i,t);}catch(Throwable ignored){}}
    private static void safeCompleted(Listener l,Bitmap b,int i){try{l.completed(b,i);}catch(Throwable ignored){}}
    private static void safeFailed(Listener l,String m,int i){try{l.failed(m,i);}catch(Throwable ignored){}}
    public boolean isModelInUse(String path){return path!=null&&modelRefs.containsKey(new File(path).getAbsolutePath());}
    public State state(String id){return states.get(id);}
    public int pendingCount(){return queue.size();}
    public List<String> queuedIds(){List<String> out=new ArrayList<>();for(Work w:queue)out.add(w.job.id);return out;}
    public void cancelPending(){for(Work w:queue){w.cancelled.set(true);states.put(w.job.id,State.CANCELLED);releaseModel(w.job.model);}queue.clear();}
    private void releaseModel(File model){if(model==null)return;String p=model.getAbsolutePath();modelRefs.computeIfPresent(p,(k,v)->v<=1?null:v-1);}
    public void shutdown(){stopped.set(true);cancelPending();worker.shutdownNow();}
}
