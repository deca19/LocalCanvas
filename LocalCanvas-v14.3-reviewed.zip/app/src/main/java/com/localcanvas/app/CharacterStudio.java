package com.localcanvas.app;

import android.content.Context;import java.util.*;

/** Stores character profiles locally so repeated generations can reuse the same description. */
public final class CharacterStudio{
 public static final class CharacterProfile{public final String name,hair,hairColor,eyeColor,clothing,expression,pose,background;CharacterProfile(String n,String h,String hc,String e,String c,String x,String p,String b){name=n;hair=h;hairColor=hc;eyeColor=e;clothing=c;expression=x;pose=p;background=b;}public String prompt(){return name+", "+hair+", "+hairColor+" hair, "+eyeColor+" eyes, "+clothing+", "+expression+", "+pose+", "+background;}}
 private final android.content.SharedPreferences p;public CharacterStudio(Context c){p=c.getSharedPreferences("characters",Context.MODE_PRIVATE);}
 public void save(CharacterProfile x){p.edit().putString(x.name,String.join("|",x.hair,x.hairColor,x.eyeColor,x.clothing,x.expression,x.pose,x.background)).apply();}
 public CharacterProfile get(String n){String z=p.getString(n,null);if(z==null)return null;String[] a=z.split("\\|",-1);if(a.length!=7)return null;return new CharacterProfile(n,a[0],a[1],a[2],a[3],a[4],a[5],a[6]);}
 public Set<String> names(){return new TreeSet<>(p.getAll().keySet());}public void delete(String n){p.edit().remove(n).apply();}
}
