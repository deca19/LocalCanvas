package com.localcanvas.app;

import android.content.Context;
import android.net.Uri;
import android.os.StatFs;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Model files live in private storage. Approximate catalog size is never used as exact file size. */
public final class ModelManager {
    public interface Progress { void onProgress(long done, long total, long elapsedMs); }
    public static final class Model {
        public final String id,name,architecture,license,downloadUrl,sha256; public final long expectedBytes; public final File file;
        Model(String i,String n,String a,String l,long e,String u,String h,File f){id=i;name=n;architecture=a;license=l;expectedBytes=e;downloadUrl=u;sha256=h;file=f;}
        public boolean isInstalled(){return file.isFile()&&file.length()>0;}
    }
    private static final class Spec {final String id,name,arch,license,url,sha;final long estimate;Spec(String i,String n,String a,String l,long e,String u,String h){id=i;name=n;arch=a;license=l;estimate=e;url=u;sha=h;}}
    private static final List<Spec> CATALOG=Arrays.asList(
        new Spec("sd15","Stable Diffusion 1.5","SD 1.x","CreativeML Open RAIL-M",4270000000L,"https://huggingface.co/stable-diffusion-v1-5/stable-diffusion-v1-5/resolve/main/v1-5-pruned-emaonly.safetensors",null),
        new Spec("sd2","Stable Diffusion 2.x","SD 2.x","라이선스 원문 확인 필요",0,null,null),
        new Spec("sdxl","Stable Diffusion XL","SDXL","Stability AI license",6940000000L,"https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors","31e35c80fc4829d14f90153f4c74cd59c90b779f6afe05a74cd6120b893f7e5b"),
        new Spec("illustrious-xl","Illustrious XL","SDXL derivative","저작자 라이선스 확인 필요",0,null,null),
        new Spec("noobai-xl","NoobAI XL","SDXL derivative","저작자 라이선스 확인 필요",0,null,null),
        new Spec("pony-xl","Pony Diffusion XL","SDXL derivative","저작자 라이선스 확인 필요",0,null,null),
        new Spec("animagine-xl","Animagine XL","SDXL derivative","저작자 라이선스 확인 필요",0,null,null),
        new Spec("flux","FLUX","DiT/FLUX","접근 조건 확인 필요",0,null,null),
        new Spec("sd35","Stable Diffusion 3.5","MMDiT","접근 조건 확인 필요",0,null,null));
    private final Context context; private final File root;
    public ModelManager(Context c){context=c.getApplicationContext();root=new File(context.getFilesDir(),"models");root.mkdirs();}
    public File directory(){return root;}
    private File fileFor(String id){return new File(root,id+".model");}
    private static void validId(String id){if(id==null||!id.matches("[A-Za-z0-9][A-Za-z0-9._-]{0,63}"))throw new IllegalArgumentException("모델 ID 형식이 올바르지 않습니다");}
    public long freeBytes(){return new StatFs(root.getAbsolutePath()).getAvailableBytes();}
    public List<Model> list(){List<Model> out=new ArrayList<>();for(Spec s:CATALOG)out.add(new Model(s.id,s.name,s.arch,s.license,s.estimate,s.url,s.sha,fileFor(s.id)));File[] fs=root.listFiles((d,n)->n.endsWith(".model"));if(fs!=null)for(File f:fs){String id=f.getName().substring(0,f.getName().length()-6);boolean known=false;for(Spec s:CATALOG)if(s.id.equals(id))known=true;if(!known)out.add(new Model(id,"사용자 모델: "+id,"사용자 지정","사용자 확인",f.length(),null,null,f));}return out;}
    public Model find(String id){if(id==null)return null;for(Model m:list())if(id.equals(m.id))return m;return null;}
    public synchronized File importFile(Uri uri,String id)throws IOException{validId(id);File dest=fileFor(id),part=new File(dest+".import.part");if(GenerationQueue.shared().isModelInUse(dest.getAbsolutePath()))throw new IOException("사용 중인 모델입니다");try(InputStream in=context.getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("파일을 열 수 없습니다");copy(in,part,null,new AtomicBoolean(false));}validateFormat(part);atomicReplace(part,dest);return dest;}
    /** Downloads with resumable range support. expected is optional SHA-256, not a size. */
    public synchronized File download(String id,String url,String expected,Progress progress,AtomicBoolean cancel)throws Exception{
        validId(id);if(url==null||!url.toLowerCase(Locale.US).startsWith("https://"))throw new IllegalArgumentException("HTTPS 주소만 허용합니다");
        File dest=fileFor(id),part=new File(dest+".part");long offset=part.isFile()?part.length():0; if(GenerationQueue.shared().isModelInUse(dest.getAbsolutePath()))throw new IOException("사용 중인 모델입니다");long started=System.currentTimeMillis();HttpURLConnection h=null;
        try{
            long safety=32L*1024L*1024L;
            if(offset>0&&freeBytes()<safety)throw new IOException("다운로드 재개에 필요한 저장 공간이 부족합니다");
            h=(HttpURLConnection)new URL(url).openConnection();h.setConnectTimeout(20000);h.setReadTimeout(60000);h.setInstanceFollowRedirects(true);h.setRequestProperty("Accept-Encoding","identity");if(offset>0){h.setRequestProperty("Range","bytes="+offset+"-");String savedTag=readMeta(new File(part+".meta"));if(savedTag!=null&&!savedTag.isEmpty())h.setRequestProperty("If-Range",savedTag);}h.connect();int code=h.getResponseCode();
            if(code==416&&offset>0){part.delete();h.disconnect();return download(id,url,expected,progress,cancel);}
            if(code!=200&&code!=206)throw new IOException("HTTP "+code);
            String range=h.getHeaderField("Content-Range");long content=h.getContentLengthLong();long total;
            String responseTag=h.getHeaderField("ETag");String savedTag=readMeta(new File(part+".meta"));if(responseTag!=null&&!responseTag.isEmpty())try{java.nio.file.Files.write(new File(part+".meta").toPath(),responseTag.getBytes(java.nio.charset.StandardCharsets.UTF_8));}catch(Exception ignored){}
            if(offset>0){if(code==206){if(savedTag==null||savedTag.startsWith("W/")||responseTag==null||!savedTag.equals(responseTag)){part.delete();new File(part+".meta").delete();offset=0;h.disconnect();return download(id,url,expected,progress,cancel);}DownloadValidator.Range parsed=DownloadValidator.parseContentRange(range);if(parsed.start!=offset||parsed.end!=parsed.total-1||(content>=0&&content!=parsed.end-parsed.start+1))throw new IOException("Content-Range가 로컬 파일과 일치하지 않습니다");total=parsed.total;}else{part.delete();new File(part+".meta").delete();offset=0;h.disconnect();return download(id,url,expected,progress,cancel);}}
            else if(code==206){DownloadValidator.Range parsed=DownloadValidator.parseContentRange(range);if(parsed.start!=0||parsed.end!=parsed.total-1||(content>=0&&content!=parsed.total))throw new IOException("잘못된 전체 응답 범위");total=parsed.total;}else total=content;
            if(total>0&&freeBytes()-safety<Math.max(0,total-offset))throw new IOException("다운로드에 필요한 저장 공간이 부족합니다");
            try(InputStream in=new BufferedInputStream(h.getInputStream());OutputStream out=new BufferedOutputStream(new FileOutputStream(part,offset>0))){copy(in,out,progress,cancel,offset,total,started,root);}
            if(cancel!=null&&cancel.get())throw new CancellationException("다운로드가 취소되었습니다");if(!part.isFile()||part.length()==0)throw new IOException("빈 파일입니다");
            if(total>0&&part.length()!=total)throw new IOException("다운로드가 완전히 끝나지 않았습니다: "+part.length()+"/"+total);
            if(expected!=null&&!expected.trim().isEmpty()&&!expected.equalsIgnoreCase(hash(part)))throw new IOException("SHA-256 무결성 검사 실패");
            validateFormat(part);atomicReplace(part,dest);new File(part+".meta").delete();return dest;
        }catch(CancellationException e){throw e;}catch(Exception e){throw e;}finally{if(h!=null)h.disconnect();}
    }
    private static long parseRangeStart(String x)throws IOException{if(x==null||!x.startsWith("bytes "))throw new IOException("Content-Range가 없습니다");try{return Long.parseLong(x.substring(6,x.indexOf('-')));}catch(Exception e){throw new IOException("Content-Range가 올바르지 않습니다");}}
    private static long parseRangeTotal(String x){if(x==null)return-1;int slash=x.indexOf('/');if(slash<0)return-1;try{return Long.parseLong(x.substring(slash+1).trim());}catch(Exception e){return-1;}}
    private static String readMeta(File f){if(!f.isFile())return null;try{String s=new String(java.nio.file.Files.readAllBytes(f.toPath()),java.nio.charset.StandardCharsets.UTF_8).trim();return s.isEmpty()?null:s;}catch(Exception e){return null;}}
    private static void copy(InputStream in,File file,Progress p,AtomicBoolean cancel)throws IOException{try(OutputStream out=new BufferedOutputStream(new FileOutputStream(file))){copy(in,out,p,cancel,0,-1,System.currentTimeMillis(),file.getParentFile());}}
    private static void copy(InputStream in,OutputStream out,Progress p,AtomicBoolean cancel,long offset,long total,long started,File spaceRoot)throws IOException{byte[] buf=new byte[1024*1024];long done=offset;int n;while((n=in.read(buf))!=-1){if(cancel!=null&&cancel.get())throw new CancellationException("다운로드가 취소되었습니다");out.write(buf,0,n);done+=n;if(spaceRoot.getUsableSpace()-32L*1024L*1024L< (total>0?Math.max(0,total-done):0))throw new IOException("다운로드 중 저장 공간이 부족합니다");if(p!=null)p.onProgress(done,total,System.currentTimeMillis()-started);}}
    static void atomicReplace(File part,File dest)throws IOException{ AtomicModelFile.replace(part,dest); }
    private static void validateFormat(File f)throws IOException{if(!DownloadValidator.isSupportedModel(f))throw new IOException("지원되지 않거나 손상된 모델 파일 형식입니다");}
    public synchronized boolean remove(String id){validId(id);File f=fileFor(id);if(GenerationQueue.shared().isModelInUse(f.getAbsolutePath())||NativeEngine.isGeneratingSafe())return false;if(NativeEngine.isNativeLibraryLoaded()&&!NativeEngine.nativeUnload())return false;File p=new File(f+".part");return(!f.exists()||f.delete())&&(!p.exists()||p.delete());}
    public static String hash(File f)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[]b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte b:md.digest())s.append(String.format(Locale.US,"%02x",b));return s.toString();}
}
