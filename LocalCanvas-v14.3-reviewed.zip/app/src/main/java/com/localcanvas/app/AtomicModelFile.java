package com.localcanvas.app;
import java.io.*;
import java.nio.file.*;
/** Same-filesystem atomic replacement; fail closed rather than delete or copy over the old model. */
final class AtomicModelFile {
 static void replace(File part, File dest) throws IOException {
  if (!part.isFile() || part.length()==0 || part.getCanonicalFile().equals(dest.getCanonicalFile())) throw new IOException("Invalid replacement");
  if (!part.getCanonicalFile().getParentFile().equals(dest.getCanonicalFile().getParentFile())) throw new IOException("Replacement must be staged in destination directory");
  try (RandomAccessFile f=new RandomAccessFile(part,"rw")) { f.getFD().sync(); }
  Files.move(part.toPath(),dest.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
 }
}
