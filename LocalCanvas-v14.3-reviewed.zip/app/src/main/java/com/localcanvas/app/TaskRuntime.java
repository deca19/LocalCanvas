package com.localcanvas.app;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Process-scoped executors shared by recreated Activities. */
public final class TaskRuntime {
    private static final ExecutorService FILE_EXECUTOR=Executors.newSingleThreadExecutor();
    private TaskRuntime(){}
    public static ExecutorService fileExecutor(){return FILE_EXECUTOR;}
}
