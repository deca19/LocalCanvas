package com.localcanvas.app;

import android.content.Context;
import java.util.*;

/** Offline prompt presets and safe tag suggestions; no paid API is used. */
public final class PromptStudio {
    private final android.content.SharedPreferences prefs;
    private static final String[] TAGS={"masterpiece","best quality","highly detailed","solo","portrait","full body","cinematic lighting","soft lighting","outdoors","indoors","smile","looking at viewer"};
    public PromptStudio(Context c){prefs=c.getSharedPreferences("prompt_studio",Context.MODE_PRIVATE);}
    public List<String> suggestions(String prefix){List<String> out=new ArrayList<>();String q=prefix==null?"":prefix.toLowerCase(Locale.US);for(String t:TAGS)if(q.isEmpty()||t.contains(q))out.add(t);return out;}
    public void save(String name,String prompt,String negative){prefs.edit().putString("p."+name,prompt).putString("n."+name,negative).apply();}
    public String prompt(String name){return prefs.getString("p."+name,"");}public String negative(String name){return prefs.getString("n."+name,"");}
    public Set<String> names(){Set<String> s=new TreeSet<>();for(String k:prefs.getAll().keySet())if(k.startsWith("p."))s.add(k.substring(2));return s;}
    public String randomTags(int count){List<String> a=new ArrayList<>(Arrays.asList(TAGS));Collections.shuffle(a);return String.join(", ",a.subList(0,Math.max(0,Math.min(count,a.size()))));}
}
