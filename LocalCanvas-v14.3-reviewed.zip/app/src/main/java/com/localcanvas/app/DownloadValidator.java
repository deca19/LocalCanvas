package com.localcanvas.app;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure, bounded model/download validation. It never treats a magic prefix as a complete model. */
public final class DownloadValidator {
    private static final long MAX_SAFE_TENSOR_HEADER = 100L * 1024L * 1024L;
    private static final long MAX_GGUF_COUNT = 100_000_000L;
    private static final Pattern OFFSET_PAIR = Pattern.compile("\\\"data_offsets\\\"\\s*:\\s*\\[(\\d+)\\s*,\\s*(\\d+)\\s*\\]");
    private DownloadValidator() {}
    public static final class Range { public final long start,end,total; Range(long s,long e,long t){start=s;end=e;total=t;} }
    public static Range parseContentRange(String value) throws IOException {
        if(value==null||!value.startsWith("bytes ")) throw new IOException("Content-Range 없음");
        int dash=value.indexOf('-',6), slash=value.indexOf('/',dash+1); if(dash<0||slash<0) throw new IOException("Content-Range 형식 오류");
        try { long s=Long.parseLong(value.substring(6,dash)); long e=Long.parseLong(value.substring(dash+1,slash)); long t=Long.parseLong(value.substring(slash+1)); if(s<0||e<s||t<=e) throw new IOException("Content-Range 범위 오류"); return new Range(s,e,t); } catch(NumberFormatException e){throw new IOException("Content-Range 숫자 오류",e);}
    }
    public static boolean acceptsResume(String range,long offset,long localLength) throws IOException { Range r=parseContentRange(range); return r.start==offset&&offset==localLength&&r.end==r.total-1; }
    public static boolean isSupportedModel(File file) throws IOException {
        if(file==null||!file.isFile()||file.length()<8) return false;
        try(RandomAccessFile in=new RandomAccessFile(file,"r")){byte[] magic=new byte[4];in.readFully(magic);if(new String(magic,StandardCharsets.US_ASCII).equals("GGUF"))return validGguf(in,file.length());in.seek(0);return validSafeTensors(in,file.length());}
    }
    private static boolean validGguf(RandomAccessFile in,long fileLength)throws IOException {if(fileLength<24)return false;long version=readUnsignedLe32(in),tensors=readLe64(in),metadata=readLe64(in);if(version<1||version>3||tensors<=0||metadata<=0||tensors>MAX_GGUF_COUNT||metadata>MAX_GGUF_COUNT)return false;return fileLength>=24+metadata*12+tensors*32+1;}
    private static boolean validSafeTensors(RandomAccessFile in,long fileLength)throws IOException {long headerLength=Long.reverseBytes(in.readLong());if(headerLength<=0||headerLength>fileLength-8||headerLength>MAX_SAFE_TENSOR_HEADER)return false;byte[] header=new byte[(int)headerLength];in.readFully(header);String json=new String(header,StandardCharsets.UTF_8).trim();if(!json.startsWith("{")||!json.endsWith("}")||!json.contains("\"dtype\"")||!json.contains("\"shape\"")||!json.contains("\"data_offsets\""))return false;Matcher m=OFFSET_PAIR.matcher(json);int pairs=0;long dataStart=8+headerLength;while(m.find()){long start=Long.parseLong(m.group(1)),end=Long.parseLong(m.group(2));if(start>end||dataStart>fileLength||end>fileLength-dataStart)return false;pairs++;}return pairs>0;}
    private static long readUnsignedLe32(RandomAccessFile in)throws IOException{return Integer.toUnsignedLong(Integer.reverseBytes(in.readInt()));}
    private static long readLe64(RandomAccessFile in)throws IOException{return Long.reverseBytes(in.readLong());}
}
