package com.localcanvas.app;

import android.content.Context;import android.os.StatFs;import java.io.*;

/** Reports actual app-private storage usage; it never invents GPU or thermal values. */
public final class StorageCenter{
 private final Context c;public StorageCenter(Context x){c=x.getApplicationContext();}
 public long freeBytes(){return new StatFs(c.getFilesDir().getAbsolutePath()).getAvailableBytes();}
 public long directoryBytes(File f){if(f==null||!f.exists())return 0;if(f.isFile())return f.length();long n=0;File[] a=f.listFiles();if(a!=null)for(File x:a)n+=directoryBytes(x);return n;}
 public long modelsBytes(){return directoryBytes(new File(c.getFilesDir(),"models"));}public long galleryBytes(){return directoryBytes(new File(c.getFilesDir(),"gallery"));}public long cacheBytes(){return directoryBytes(c.getCacheDir());}
 public String report(){return "모델: "+modelsBytes()/1024/1024+" MB\n갤러리: "+galleryBytes()/1024/1024+" MB\n캐시: "+cacheBytes()/1024/1024+" MB\n사용 가능: "+freeBytes()/1024/1024+" MB";}
}
