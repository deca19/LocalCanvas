package com.localcanvas.app;

import android.content.Context;import java.io.*;import java.util.*;

/** Project folders and scene metadata are kept outside model storage. */
public final class ProjectManager{
 private final File root;public ProjectManager(Context c){root=new File(c.getFilesDir(),"projects");root.mkdirs();}
 public File create(String id)throws IOException{if(id==null||!id.matches("[A-Za-z0-9._-]{1,64}"))throw new IOException("프로젝트 이름이 올바르지 않습니다");File f=new File(root,id);if(!f.exists()&&!f.mkdirs())throw new IOException("프로젝트 폴더를 만들 수 없습니다");new File(f,"scenes").mkdirs();return f;}
 public List<File> list(){File[] a=root.listFiles(File::isDirectory);return a==null?new ArrayList<>():new ArrayList<>(Arrays.asList(a));}
 public File scene(File project,String name)throws IOException{File f=new File(new File(project,"scenes"),name+".txt");if(!f.getParentFile().exists()&&!f.getParentFile().mkdirs())throw new IOException("장면 폴더를 만들 수 없습니다");return f;}
 public File root(){return root;}
}
