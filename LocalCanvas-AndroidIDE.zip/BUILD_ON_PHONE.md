# S26 Ultra에서 APK 만들기

## 준비

1. S26 Ultra에 AndroidIDE를 설치합니다.
2. 이 ZIP을 휴대폰의 Download 폴더에 저장합니다.
3. AndroidIDE에서 ZIP을 압축 해제한 프로젝트 폴더를 엽니다.
4. AndroidIDE Terminal에서 필요한 SDK를 설치합니다.

```bash
idesetup
```

5. 프로젝트 동기화가 끝나면 Terminal에서 실행합니다.

AndroidIDE의 상단 Build 버튼에서 `assembleDebug`를 선택합니다. Terminal을 사용할 경우 AndroidIDE가 제공하는 Gradle 명령으로 다음을 실행합니다.

```bash
gradle assembleDebug
```

## APK 위치

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 중요한 제한

이 1차 APK는 앱 화면과 모델 관리 구조를 검증하는 버전입니다. 네이티브 AI 추론 엔진이 아직 포함되지 않았으므로 생성 버튼을 눌러도 가짜 이미지를 만들지 않고 엔진 미연결 안내를 표시합니다.

실제 생성 엔진을 추가하려면 이후에 Android NDK와 C/C++ JNI 모듈을 연결해야 합니다.
