package com.localcanvas.app;

import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout root, content; TextView title; final int BG=Color.rgb(11,11,18), CARD=Color.rgb(25,25,37), TEXT=Color.WHITE, MUTED=Color.rgb(170,170,190), ACCENT=Color.rgb(167,139,250);
  @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
  TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(size);t.setPadding(20,14,20,14);return t;}
  Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setAllCaps(false);b.setBackgroundColor(CARD);return b;}
  void base(String name){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);title=tv(name,24);root.addView(title);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout nav=new LinearLayout(this);String[] ns={"홈","생성","모델","갤러리","설정"};for(String n:ns){Button x=btn(n);nav.addView(x,new LinearLayout.LayoutParams(0,64,1));if(n.equals("홈"))x.setOnClickListener(v->showHome());if(n.equals("생성"))x.setOnClickListener(v->showGenerate());if(n.equals("모델"))x.setOnClickListener(v->showModels());if(n.equals("갤러리"))x.setOnClickListener(v->showGallery());if(n.equals("설정"))x.setOnClickListener(v->showSettings());}root.addView(nav);setContentView(root);}
  void card(String s){TextView t=tv(s,16);t.setBackgroundColor(CARD);content.addView(t,new LinearLayout.LayoutParams(-1,-2));}
  void showHome(){base("LocalCanvas");card("모바일 로컬 이미지 생성\n\n현재 상태: 엔진 연결 전\n이 앱은 서버/API 없이 기기에서 생성하는 것을 목표로 합니다.");Button b=btn("이미지 생성 시작");b.setOnClickListener(v->showGenerate());content.addView(b);card("안전한 진행 원칙\n• 실제 생성 엔진이 연결되기 전에는 결과 이미지를 만들지 않습니다.\n• 기기에서 측정할 수 없는 성능 수치는 표시하지 않습니다.\n• 모델 라이선스와 호환성을 확인한 뒤 설치합니다.");}
  void showGenerate(){base("이미지 생성");EditText p=new EditText(this);p.setHint("프롬프트를 입력하세요");p.setTextColor(TEXT);p.setHintTextColor(MUTED);content.addView(p);EditText n=new EditText(this);n.setHint("네거티브 프롬프트");n.setTextColor(TEXT);n.setHintTextColor(MUTED);content.addView(n);card("모델: 설치된 모델 없음\n품질 모드: Balanced\n해상도: 512 × 512");Button b=btn("생성 엔진이 설치되면 생성 가능");b.setOnClickListener(v->Toast.makeText(this,"현재는 실제 엔진이 연결되지 않았습니다.",Toast.LENGTH_LONG).show());content.addView(b);}
  void showModels(){base("모델 관리");card("모델 ON/OFF 시스템");for(String s:new String[]{"Stable Diffusion 1.5 · 미설치","SDXL · 미설치","FLUX · 미검증","사용자 지정 모델 · 파일 선택 예정"}){Button b=btn(s+"\n설치하려면 탭");b.setOnClickListener(v->Toast.makeText(this,"모델 저장소 및 무결성 검사를 연결할 예정입니다.",Toast.LENGTH_SHORT).show());content.addView(b);}}
  void showGallery(){base("갤러리");card("생성된 이미지가 없습니다.\n실제 엔진으로 생성한 이미지와 메타데이터가 여기에 저장됩니다.");}
  void showSettings(){base("설정");card("한국어\n다크 테마\n오프라인 생성 우선\n기기 상태 측정은 Android 권한 범위 내 실제 값만 표시");}
}
